package com.filemonitor.prueba.fileobserver;

public enum typeofevents {
    CREATE,
    DELETE,
    ACCESS,
    MODIFY,
    OPEN,
    CLOSE_NOWRITE,
    CLOSE_WRITE,
    DELETE_SELF,
    ATTRIB,
    MOVED_FROM,
    MOVED_TO,
    MOVED_SELF,
    UNKNOWN
}
